document.querySelector('.cta-btn').addEventListener('click', () => {
    document.querySelector('.movie-row').scrollIntoView({ behavior: 'smooth' });
  });
  